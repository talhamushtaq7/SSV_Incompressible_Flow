clear
clc
close all
% This code is created for computing SSV for channel flow and couette flow
% systems. 
%
% It is based on the paper titled "Structured Singular Value of a Repeated
% Complex Full Block Uncertainty" published in International Journal of
% Robust and Nonlinear Control (2023)
%
%
% Authors: Talha Mushtaq, Diganta Bhattacharjee, Peter Seiler, Maziar S. Hemati
%% Specify Parameters
na = 50; % Number of streamwise wave numbers
nb = 90; % Number of spanwise wave numbers
nf = 25; %100; % Number of (positive) frequency points
N = 30; % Number of Collocation points (Excluding walls)

kx = logspace(-4,0.48,na); % Streamwise wave number range
kz = logspace(-2,1.2,nb); % Spanwise wave number range
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
flag = 1; % flag = 0 (Channel Flow), flag = 1 (Couette Flow), flag = 2 (Turbulent Channel Flow)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
flag_func = 1; % flag_func = 0 (Non-Repeated Complex Full Block), flag_func = 1 (Repeated Complex Full Block),
%                flag_func = 2 (Osborne's method for Non-Repeated Complex Full Block),
%                flag_func = 3 (Unstructured - H_\inf), flag_func = 4 (Complex Scalar)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
flag_A = 0; % flag for checking eigenvalues of A
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Frequency
w1 = logspace(-4,0.5,nf); 
w = sort([-w1,w1]);
%% Bound Calculation
clc
if flag==0
    Re = 690; % Reynolds number for Channel flow
elseif flag==1
    Re = 358; % Reynolds number for Couette flow
end
%
% Define Cpu Cores for Parallel Looping otherwise default MATLAB setting
% are used
%
% no_of_cpu_cores = 6;
% cl = parcluster('local');
% pool = cl.parpool(no_of_cpu_cores);
if flag_A == 1
% Eigenvalue check of the system matrix A
    eigm = zeros(length(kx),length(kz));
    for ii = 1:length(kx)
        for jj = 1:length(kz)
            [linop] = get_linear_operator(Re,kx(ii),kz(jj),N,flag);
            A = linop.A; % System matrix
            eigm(ii,jj) = max(real(eig(A)));
        end
    end
    
    %% Eigenvalue Plotting for A
    figure()
    pcolor(kz,kx,eigm);
    shading interp
    % title('$log_{10}\|H_{\nabla}\|_\mu$','interpreter','latex');
    xlabel('$\kappa_z$','interpreter','latex');
    ylabel('$\kappa_x$','interpreter','latex');
    set(gca,'Xscale','log','Yscale','log','Fontsize',15)
    % set(gca,'Fontsize',15)
    colormap jet
    colorbar
    xlim([min(kz) max(kz)])
    ylim([min(kx) max(kx)])
    % clim([1 3])
    
    %% Real and Imaginary Component of Eigenvalue for A
    figure()
    plot(real(eig(A)), imag(eig(A)), 'ko', 'linewidth',1.5);
    xlabel('Re(\lambda)');
    ylabel('Im(\lambda)');
    set(gca,'Fontsize',15);
    grid on;
end
%% SSV computation
tst = tic;
parfor ii = 1:length(w)
    disp(ii)
    [ub{ii},lb{ii}] = mu_calc(w(ii),Re,N,kx,kz,flag, flag_func);
end
tend = toc(tst);
[Z_mu_ub, fmax_ub, G_ub] = mumax(ub,w,kx,kz);

if flag_func == 0 || flag_func == 1
    [Z_mu_lb, fmax_lb, G_lb] = mumax(lb,w,kx,kz);
end

% delete(gcp('nocreate'))
%% Time Elapsed
close all
if tend >= 60
    if tend/60 > 60
        fprintf('Time elapsed (hrs): %0.3f \n',tend/3600)
    else
        fprintf('Time elapsed (min): %0.3f \n',tend/60)
    end
else
    fprintf('Time elapsed (sec): %0.3f \n',tend)
end
fprintf('Time elapsed per wavenumber per freq (sec): %0.3f \n',tend/(2*na*nb*nf))
%% Quality of Bounds
% if flag_func == 0 || flag_func == 1
UB = 10.^Z_mu_ub; LB = 10.^Z_mu_lb;
Rlog = 100.*(UB - LB)./LB;
plot_contours(kz,kx,Rlog);
% clim([0 1.01*max(max(Rlog))])
clim([0 10])
% end
%% Upper Bound Plot
plot_contours(kz,kx,Z_mu_ub);
clim([1 3]);
%% Lower Bound Plot
if flag_func == 0 || flag_func == 1
    plot_contours(kz,kx,Z_mu_lb);
    clim([1 3]);
end

%% Surface Plot
figure()
for ii = 1:length(w)
    surf(kz,kx,ub{ii}); hold on
end

xlabel('$k_z$','Interpreter','latex');
ylabel('$k_x$','Interpreter','latex');
zlabel('$Upper-Bound$','Interpreter','latex');
set(gca,'Xscale','log','Yscale','log','Fontsize',15);
%% frequency vs upper-bound
Z = Z_mu_ub; G = G_ub;

[val,ind] = max(Z);
[val2,ind2] = max(val);

ridx = ind(ind2);
cidx = ind2;
alp = reshape(G(ridx,cidx,:),1,[]);

figure()
plot(w,alp,'r-','linewidth',1.5);
xlabel('$\omega$','interpreter','latex');
ylabel('$\|H_\nabla\|_\mu$','interpreter','latex');
set(gca,'Fontsize',15);
xlim([min(w), max(w)]);
title('$\mu \; vs \; \omega \;$','interpreter','latex');
