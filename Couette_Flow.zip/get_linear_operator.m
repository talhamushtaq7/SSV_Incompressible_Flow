% Form Orr-Sommerfeld-Squire Operator for the channel flow
% linearized about the baseflow.

function [linop] = get_linear_operator(Re,kx,kz,N,flag)

% Re = Reynolds number (using channel half-height)
% alpha = [alpha1 alpha2] --> end points on range of streamwise wave numbers
% beta = [beta1 beta2] --> end points on range of spanwise wave numbers
% N = # Chebyshev points in wall-normal direction

cdiff = get_diff(N);
bf = get_baseflow(cdiff,Re,flag);

I = eye(N);
y = cdiff.y;

% Form OSS for each wavenumber pair (kx,kz) by looping over
% the grid defined by (alpha,beta)
% NN = Nstate*length(alpha(1):alpha(2))*length(beta(1):beta(2));

NN = length(kx)*length(kz);

% Form Laplacian
k2 = kx^2 + kz^2;
lap = (cdiff.D2 - k2 * I);
lap2 = (cdiff.D4 - 2 * k2 * cdiff.D2 + k2 * k2 * I);

% Form OSS system
Los  = -1i*kx*I*diag(bf.u)*(lap) + (1i*kx*I)*diag(bf.udblprime) + (lap2./Re);
Lsq   = -1i*kx*I*diag(bf.u) + (lap)./Re;
Lc    = -(1i*kz*I)*diag(bf.uprime);

A = [lap\Los  zeros(N,N); Lc  Lsq];
% And input-output operators from/to velocities in wavenumber space
B = [lap\(-1i*kx*I*cdiff.D1), lap\(-k2*I), lap\(-1i*kz*I*cdiff.D1);...
    1i*kz*I, zeros(N,N), -1i*kx*I];
C = [1i*kx*cdiff.D1/k2, -1i*kz*I/k2; ...
    I,  zeros(N,N); ...
    1i*kz*cdiff.D1/k2, 1i*kx*I/k2];

% New output matrix for H_grad
Grad = [1i*kx*I;cdiff.D1;1i*kz*I];

Grad_mat = blkdiag(Grad,Grad,Grad);
C_grad = Grad_mat*C;

[Q,W] = quad_weights(N,cdiff,k2);
R = sqrtm(Q);
Iw = sqrtm(blkdiag(W,W,W));
IN = blkdiag(Iw,Iw,Iw);
If = sqrtm(blkdiag(W,W));
% Now allocate it into a larger operator with all (kx,kz)


linop.A = A;
linop.B = B;
linop.C = C;
linop.Q = Q;
linop.R = R;
linop.Iw = Iw;
linop.IN = IN;
linop.If = If;
linop.C_grad = C_grad;
linop.bf = bf;
linop.n  = NN;
linop.Grad_mat = Grad_mat;
linop.Grad = Grad;
linop.y = y;
end