function cdiff = get_diff(N)

% get differentiation matrices
[y,D] = chebdif(N+2,2);
cdiff.y=y(2:N+1);  %remove end points for zero BC at walls

% implement homogeneous boundary conditions
cdiff.D1 = D(2:N+1,2:N+1,1);
cdiff.D2=D(2:N+1,2:N+1,2);

% fourth derivative with clamped conditions
[~,D4]=cheb4c(N+2);
cdiff.D4 = D4;