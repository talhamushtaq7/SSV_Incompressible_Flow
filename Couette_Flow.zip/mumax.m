function [Z, fmax, G, zeta] = mumax(ub,fGrid,kx,kz)

for ii = 1:length(fGrid)
    G(:,:,ii) = ub{ii};
end

for ii = 1:length(fGrid)
    zeta(ii) = norm(G(:,:,ii));
end

for jj = 1:length(kx)
    for kk = 1:length(kz)
        [ubmax(jj,kk),ind] = max(G(jj,kk,:));
        fmax(jj,kk) = fGrid(ind);
    end
end
Z = log10(real(ubmax));

end