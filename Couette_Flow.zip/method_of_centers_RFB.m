function [ub,data] = method_of_centers_RFB(freq,lb,Re,N,kx,kz,flag)

ratio = 1.01;

for ii = 1:length(kx)
    for jj = 1:length(kz)
        [linop] = get_linear_operator(Re,kx(ii),kz(jj),N,flag);

        A = linop.A;
        B = linop.B;
        C_grad = linop.C_grad;
        Grad = linop.Grad;
        IN = linop.IN;
        Iw = linop.Iw;
        R = linop.R;

        nrc_grad = size(C_grad,1);
        ncb = size(B,2);

        H_grad = ss(R*A/R, R*B, C_grad/R, zeros(nrc_grad,ncb));
        M = evalfr(H_grad, freq*1i);
        M = IN * M / Iw;

        blkstruct = [ncb/3, nrc_grad/3;...
            ncb/3, nrc_grad/3;...
            ncb/3, nrc_grad/3];

        % Initialize with Osborne method
        [~,Dosb,~,~,~,~,~] = osborne_scaling(M,blkstruct);
        [ub(ii,jj),S{ii,jj}] = mumocubRFB(M,Dosb'*Dosb,lb(ii,jj),ratio);

        Dleft = kron(sqrtm(S{ii,jj}),eye(nrc_grad/3));
        Dright = kron(sqrtm(S{ii,jj}),eye(ncb/3));
        [ur,~,vr] = svd(Dleft*M/Dright);
        [mu,Delta1] = exact_mu(M,N);
        y = Dleft\ur(:,1);
        y = IN\y;

        f = Dright\vr(:,1);
        f = Iw\f;


    end
end

if ii == jj && ii == 1
    % Mode Shapes
    dx = Grad(1:N,1:N); dy = Grad(N+1:2*N,1:N); dz = Grad(2*N+1:end,1:N);
    fx = f(1:N); fy = f(N+1:2*N); fz = f(2*N+1:end);
    u = dx\y(1:N); v = dx\y(3*N+1:4*N); w = dx\y(6*N+1:7*N);
    wx = dy*w - dz*v; wy = dz*u - dx*w; wz = dx*v - dy*u;

    data.fx = fx; data.fy = fy; data.fz = fz;
    data.u = u; data.v = v; data.w = w;
    data.wx = wx; data.wy = wy; data.wz = wz;
    data.y = linop.y; data.N = N; data.kx = kx;
    data.kz = kz; data.freq = freq; data.dy = dy;
else
    data = [];
end
end