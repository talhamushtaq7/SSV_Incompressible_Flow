function [Q,W] = quad_weights(N,cdiff,k)
[~,W] = clencurt(N+1);
W = diag(W(2:N+1));
T = cdiff.D1;
Q = (1/(8*k)).*blkdiag(k.*W + T'*W*T, W);

end