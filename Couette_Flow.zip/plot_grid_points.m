function plot_grid_points(kz,kx,fGrid)
figure(1)
for kk = 1:length(fGrid)
    for ii = 1:length(kz)
        for jj = 1:length(kx)
            plot3(fGrid(kk),kx(jj),kz(ii),'k*'); hold on
        end
    end
end
grid on
xlabel('$\omega$','Interpreter','latex');
ylabel('$k_x$','Interpreter','latex')
zlabel('$k_z$','Interpreter','latex')
set(gca,'Fontsize',15)

figure(2)
    for ii = 1:length(kz)
        for jj = 1:length(kx)
            plot(kx(jj),kz(ii),'k*'); hold on
        end
    end
grid on
xlabel('$k_x$','Interpreter','latex')
ylabel('$k_z$','Interpreter','latex')
set(gca,'Fontsize',15)
end