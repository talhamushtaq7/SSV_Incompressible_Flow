function [ub,data] = infnorm(freq,Re,N,kx,kz,flag)

for ii = 1:length(kx)
    for jj = 1:length(kz)
        [linop] = get_linear_operator(Re,kx(ii),kz(jj),N,flag);

        A = linop.A;
        B = linop.B;
        C_grad = linop.C_grad;
%         C = linop.C;
        IN = linop.IN;
        Iw = linop.Iw;
        R = linop.R;

        nrc_grad = size(C_grad,1);
%         nrc = size(C,1);
        ncb = size(B,2);

        H_grad = ss(R*A/R, R*B, C_grad/R, zeros(nrc_grad,ncb));
        M = evalfr(H_grad, freq*1i);
        M = IN * M / Iw;

        [ur,ub(ii,jj),vr] = svds(M,1);

        %         y = IN\ur(:,1);
        %         f = Iw\vr(:,1);


    end
end

% if ii == jj && ii == 1
%     % Mode Shapes
%     dx = Grad(1:N,1:N); dy = Grad(N+1:2*N,1:N); dz = Grad(2*N+1:end,1:N);
%     fx = f(1:N); fy = f(N+1:2*N); fz = f(2*N+1:end);
%     u = dx\y(1:N); v = dx\y(3*N+1:4*N); w = dx\y(6*N+1:7*N);
%     wx = dy*w - dz*v; wy = dz*u - dx*w; wz = dx*v - dy*u;
%
%     data.fx = fx; data.fy = fy; data.fz = fz;
%     data.u = u; data.v = v; data.w = w;
%     data.wx = wx; data.wy = wy; data.wz = wz;
%     data.y = linop.y; data.N = N; data.kx = kx;
%     data.kz = kz; data.freq = freq;
% else
data = [];
% end
end