function [ub,lb] = mu_calc(freq,Re,N,kx,kz,flag, flag_func)

%%%%% NOTE: Edits made by DB, September 2023

for ii = 1:length(kx)
    for jj = 1:length(kz)
        [linop] = get_linear_operator(Re,kx(ii),kz(jj),N,flag);

        A = linop.A; % System matrix
        B = linop.B; % Input mapping for forcings
        C_grad = linop.C_grad; % Output mapping for gradient of velocities
%         IN = linop.IN; % Square root of L2 weight for (dxu,dyu,dzu,dxv,dyv,dzv,dxw,dyw,dzw)
%         Iw = linop.Iw; % Square root of L2 weight for (u,v,w) or (fx,fy,fz)
%         R = linop.R; % Square root of Kinetic Energy Weight

        nrc_grad = size(C_grad,1);
        ncb = size(B,2);
%        %%% With operator scaling 
%         H_grad = ss(R*A/R, R*B, C_grad/R, zeros(nrc_grad,ncb));
%         M = evalfr(H_grad, freq*1i);
%         M = IN * M / Iw;

       %%% WithOUT operator scaling (Algorithms paper)
        H_grad = ss(A, B, C_grad, zeros(nrc_grad,ncb));
        M = evalfr(H_grad, freq*1i);


        blkstruct = [ncb/3, nrc_grad/3;...
                     ncb/3, nrc_grad/3;...
                     ncb/3, nrc_grad/3];


        if flag_func == 0
            % % Lower Bounds (Non-Repeated)
            %%% NOTE: edits here by DB, September 2023
            [~,~,~,~,dMd,~,~,~] = osborne_scaling(M,blkstruct);
            %
            [~,~,vo] = svds(dMd,1); %svd(M);
            vo1 = vo(:,1);
            % vo2 = vo(:,2);
            option.Iter = 60;
            option.stoptol = 1e-7;
            option.b0 = vo1;
            option.w0 = vo1; %vo2;
            option.nbrblks = 3;

            [lb(ii,jj),~,~] = mupiterlbNFB(dMd,option);
            ub = [];

%             % % Upper Bounds (Non-Repeated)
%             ratio = 1.05;
%             blkstruct = [ncb/3, nrc_grad/3;...
%                 ncb/3, nrc_grad/3;...
%                 ncb/3, nrc_grad/3];
%             % Initialize with Osborne method
%             [~,Dosb,~,~,~,~,~] = osborne_scaling(M,blkstruct);
%             [ub(ii,jj),S{ii,jj}] = mumocubNFB(M,Dosb'*Dosb,lb(ii,jj),ratio);


        elseif flag_func == 1
            % % Lower Bounds (Repeated)
            %%% NOTE: edits here by DB, September 2023
            [~,Dosb,~,~,dMd,~,~,~] = osborne_scaling(M,blkstruct);
%             [~, dMd, logd] = osborne(M,blkstruct);
%             Dosb = diag(10.^logd);
            %
            [~,~,vo] = svds(dMd,1); %svd(M);
            vo1 = vo(:,1);
            % vo2 = vo(:,2);
            option.Iter = 80;
            option.stoptol = 1e-7;
            option.b0 = vo1;
            option.w0 = vo1; %vo2;

%             blkstruct = [ncb/3, nrc_grad/3;...
%                 ncb/3, nrc_grad/3;...
%                 ncb/3, nrc_grad/3];

            [lb(ii,jj),~,~,~] = mupiterlbRFB(dMd,blkstruct,option);

            % % Upper Bounds (Repeated)
            ratio = 1.05; %1.02;
%             blkstruct = [ncb/3, nrc_grad/3;...
%             ncb/3, nrc_grad/3;...
%             ncb/3, nrc_grad/3];

        % Initialize with Osborne method
        % [~,Dosb,~,~,~,~,~] = osborne_scaling(M,blkstruct);
        %%% Normalize the Osborne d-scales -----------
        gam = min(diag(Dosb));
        Dosb = (1/gam)*Dosb;
        %%%----------------------
        [ub(ii,jj),S{ii,jj}] = mumocubRFB(M,Dosb'*Dosb,lb(ii,jj),ratio);


        elseif flag_func == 2
        % % Osborne's Iteration (Non-Repeated Upper-Bounds)
        
%             blkstruct = [ncb/3, nrc_grad/3;...
%                          ncb/3, nrc_grad/3;...
%                          ncb/3, nrc_grad/3];

        % Initialize with Osborne method
        [~,~,~,~,~,~,~,ub(ii,jj)] = osborne_scaling(M,blkstruct);
        lb = [];

        elseif flag_func == 3
            % % Unstructured (Resolvent)
            [~,ub(ii,jj),~] = svds(M,1);
            lb = [];

        end
    end
end

end