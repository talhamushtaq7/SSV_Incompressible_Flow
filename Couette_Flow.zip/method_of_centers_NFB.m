function [ub,S] = method_of_centers_NFB(freq,lb,Re,N,kx,kz,flag)

ratio = 1.05;

for ii = 1:length(kx)
    for jj = 1:length(kz)
        [linop] = get_linear_operator(Re,kx(ii),kz(jj),N,flag);

        A = linop.A; % System matrix
        B = linop.B; % Input mapping for forcings
        C_grad = linop.C_grad; % Output mapping for gradient of velocities
        IN = linop.IN; % Square root of L2 weight for (dxu,dyu,dzu,dxv,dyv,dzv,dxw,dyw,dzw)
        Iw = linop.Iw; % Square root of L2 weight for (u,v,w) or (fx,fy,fz)
        R = linop.R; % Square root of Kinetic Energy Weight

        nrc_grad = size(C_grad,1);
        ncb = size(B,2);

        H_grad = ss(R*A/R, R*B, C_grad/R, zeros(nrc_grad,ncb));
        M = evalfr(H_grad, freq*1i);
        M = IN * M / Iw;

        blkstruct = [ncb/3, nrc_grad/3;...
            ncb/3, nrc_grad/3;...
            ncb/3, nrc_grad/3];

        % Initialize with Osborne method
        [~,Dosb,~,~,~,~,~] = osborne_scaling(M,blkstruct);
        [ub(ii,jj),S{ii,jj}] = mumocubNFB(M,Dosb'*Dosb,lb(ii,jj),ratio);

    end
end
end