function [ub,D] = muprnemub(M,S0,Nu)
% Projective method to minimize the maximum singular value
% of the scaled matrix (D M D^-1).
% The code solves the following problem:
%                    minimize ub^2
% subject to
%            ub^2 Xc - (M*) Xr M >= 0
%             dmin I <= S <= dmax I
% where Xr = kron((S* S), Ir), Xc = kron((S* S), Ic) and (.)* represents
% the hermitian transpose.
%
% Algorithm reference:
% [1] Y. Nesterov and A. Nemirovskii, "Interior-point polynomial methods in convex programming", Vol. 13, Studies in Applied Mathematics
%% Options
dmin = 1e-4;
dmax = 1e4;
theta = 1e-3;
epsMC = 1e-4;

if nargin > 2
    Niter = Nu;  % 20
else
    Niter = 200;  % 20
end
%% Initialize
[nr,nc] = size(M);
v = size(S0,1);
r = nr/v; c = nc/v;
Iv = eye(v);
% Check that initial S0 is feasible
e = real(eig(S0));
emax = max(e);
emin = min(e);
if (emax > dmax || emin <dmin)
    if (emax/emin < 0.9*dmax/dmin)
        S0 = S0*(0.9*dmax/emax);
    else
        S0 = eye(v);
    end
end
%%
D = S0;
Dr = kron(D,eye(r)); Dc = kron(D,eye(c));
ub = norm(Dr*M/Dc);
[~,~,~,~,A,B,elem] = createsymbasis(v,r,c,M);

alp = 1.2*sqrt(ub);

Fstar = @(L) -real(log(det(L)));
JFstar = @(L) -inv(L)';

for kk = 1:elem
    As{kk} = null([A{kk};B{kk}]');
    Bs{kk} = diag(range([B{kk};zeros(v*c,v*c);zeros(v*c,v*c)]));
end

S = Dc;


phi_lam = @(S,lam,s,t) trace(S*(lam*Bs{s} + As{s})*S*(lam*Bs{t} + As{t}));
itr = 0;

while itr <= Niter
    itr = itr + 1;
    X = -JFstar(S);

    alprev = alp;

    for ii = 1:elem
        for jj = 1:elem
            Mat_phi(ii,jj) = phi_lam(S,alp,ii,jj);
        end
        V(ii,:) = trace((alp*Bs{ii} + As{ii})*S);
    end
    w = Mat_phi*V;
    WL = 0;

    for i = 1:elem
        WL = w(i)*(alp*Bs{ii} + As{ii}) + WL;
    end

    if abs(Fstar(WL)) ~= inf
        S = 1;
    elseif abs(Fstar(WL)) == inf
        alp = alprev; xi = WL - X;
        zeta = S*xi*S;
        rho = sqrt(trace(zeta*xi));
        t = 1/(1 + rho);
        S = S - t*zeta;
    end
end
end