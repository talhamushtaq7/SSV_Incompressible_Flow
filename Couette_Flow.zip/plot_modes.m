function plot_modes(data)
tol = 1e-5;

uvel = data.u; vvel = data.v; wvel = data.w;
wx = data.wx; wy = data.wy;
wz = data.wz; fx = data.fx; fy = data.fy; fz = data.fz;
ypts = data.y; N = data.N; freq = data.freq; kx = data.kx; kz = data.kz;
dy = data.dy;

datmat = [uvel,vvel,wvel,fx,fy,fz,wx,wy,wz];
datnorm = vecnorm(datmat,2,1);
for i = 1:length(datnorm)
    if datnorm(i) > tol
        datmat(:,i) = datmat(:,i);
    else
        datmat(:,i) = zeros(N,1);
    end
end
% Normalize Vectors
ubar = reshape(datmat(:,1:3),[],1);

fbar = reshape(datmat(:,4:6),[],1);

wbar = reshape(datmat(:,7:9),[],1);



uvel = ubar(1:N); vvel = ubar(N+1:2*N); wvel = ubar(2*N+1:3*N);
fx = fbar(1:N); fy = fbar(N+1:2*N); fz = fbar(2*N+1:3*N);
wx = wbar(1:N); wy = wbar(N+1:2*N); wz = wbar(2*N+1:3*N);

lim_u = max(max(real([uvel, vvel, wvel])));
lim_f = max(max(real([fx, fy, fz])));
lim_w = max(max(real([wx, wy, wz])));

lim_um = min(min(real([uvel, vvel, wvel])));
lim_fm = min(min(real([fx, fy, fz])));
lim_wm = min(min(real([wx, wy, wz])));

% Physical States of evolution
z = linspace(-pi(),pi(), N);
% x = linspace(0,4*pi(),N);
[zz,yy] = meshgrid(z,ypts);
% [xx,zz] = meshgrid(x,z);
x = 0; 
t = 0;
uu = data.u;
vv = data.v;
ww = data.w;
un = [uu;vv;ww];
wn = [data.wx;data.wy;data.wz];

for j = 1:length(t)
    for i = 1:length(z)
        usig(:,i,j) = un.*exp(1i*(kx*x + kz*z(i) + freq*t(j)));
        wsig(:,i,j) = wn.*exp(1i*(kx*x + kz*z(i) + freq*t(j)));
    end
end

% for j = 1:length(x)
%     for i = 1:length(z)
%         ur(i,j) = un(1).*exp(1i*(kx*x(j) + kz*z(i) + freq*t));
%         vr(i,j) = un(2).*exp(1i*(kx*x(j) + kz*z(i) + freq*t));
%         wr(i,j) = un(3).*exp(1i*(kx*x(j) + kz*z(i) + freq*t));
%     end
% end
ur = usig(1:N,:,:); vr = usig(N+1:2*N,:,:); wr = usig(2*N+1:3*N,:,:);
wxr = wsig(1:N,:,:); wyr = wsig(N+1:2*N,:,:); wzr = wsig(2*N+1:3*N,:,:);

dudx = 1i*kx*ur; dvdy = dy*vr; dwdz = 1i*kz*wr; dudy = dy*ur;
dvdx = 1i*kx*vr; dudz = 1i*kz*ur; dwdx = 1i*kx*wr; dvdz = 1i*kz*vr;
dwdy = dy*wr;
q=real(-0.5*(dudx.^2+dvdy.^2+dwdz.^2)-dudy.*dvdx-dudz.*dwdx-dvdz.*dwdy);
%% Plot the mode shapes only
figure()
plot(real(uvel),ypts,'r-','linewidth',1.5); hold on
plot(real(vvel),ypts,'b-.','linewidth',1.5);
plot(real(wvel),ypts,'k--','linewidth',1.5);
% legend('$\frac{Re(u)}{\|u\|_2}$','$\frac{Re(v)}{\|v\|_2}$','$\frac{Re(w)}{\|w\|_2}$','interpreter','latex',...
%     'location','northwest','Fontsize',21.5);
legend('$Re(\hat{u})$','$Re(\hat{v})$','$Re(\hat{w})$','interpreter','latex',...
    'location','southeast','Fontsize',21.5);
ylabel('$y$','Interpreter','latex');
xlabel('$Re(\mathbf{u})$','Interpreter','latex');
set(gca,'Fontsize',20);
xlim([1.01*lim_um lim_u])

figure()
plot(real(fx),ypts,'r-','linewidth',1.5); hold on
plot(real(fy),ypts,'b-.','linewidth',1.5);
plot(real(fz),ypts,'k--','linewidth',1.5);
% legend('$\frac{Re(f_x)}{\|f_x\|_2}$','$\frac{Re(f_y)}{\|f_y\|_2}$','$\frac{Re(f_z)}{\|f_z\|_2}$','interpreter','latex',...
%     'location','northwest','Fontsize',21.5);
legend('$Re(\hat{f}_x)$','$Re(\hat{f}_y)$','$Re(\hat{f}_z)$','interpreter','latex',...
    'location','southeast','Fontsize',21.5);
ylabel('$y$','Interpreter','latex');
xlabel('$Re(\mathbf{f})$','Interpreter','latex');
set(gca,'Fontsize',20);
xlim([1.01*lim_fm lim_f])

figure()
plot(real(wx),ypts,'r-','linewidth',1.5); hold on
plot(real(wy),ypts,'b-.','linewidth',1.5);
plot(real(wz),ypts,'k--','linewidth',1.5);
% legend('$\frac{Re(\eta_x)}{\|\eta_x\|_2}$','$\frac{Re(\eta_y)}{\|\eta_y\|_2}$','$\frac{Re(\eta_z)}{\|\eta_z\|_2}$','interpreter','latex',...
%     'location','northwest','Fontsize',21.5);
legend('$Re(\hat{\eta}_x)$','$Re(\hat{\eta}_y)$','$Re(\hat{\eta}_z)$','interpreter','latex',...
    'location','southeast','Fontsize',21.5);
ylabel('$y$','Interpreter','latex');
xlabel('$Re(\mathbf{\eta})$','Interpreter','latex');
set(gca,'Fontsize',20);
xlim([1.01*lim_wm lim_w])

for e = 1:length(t)
    figure(4)
    pcolor(zz,yy,real(ur(:,:,e))); hold on
    shading interp
    colormap default
    colorbar
    quiver(zz,yy,real(wr(:,:,e)),real(vr(:,:,e)),1.5,'k');
    xlabel('$z$','interpreter','latex');
    ylabel('$y$','interpreter','latex');
    set(gca,'Fontsize',20)
    caxis([min(min(real(ur))), max(max(real(ur)))])
    a = colorbar;
    a.Label.String = 'Re(u)';
end

%% Velocity in a real and imaginary plane
figure()
plot3(real(uvel),imag(uvel),ypts,'r-','linewidth',1.5); hold on
plot3(real(vvel),imag(vvel),ypts,'b-.','linewidth',1.5);
plot3(real(wvel),imag(wvel),ypts,'k--','linewidth',1.5);
legend('$Re(\hat{u})$','$Re(\hat{v})$','$Re(\hat{w})$','interpreter','latex',...
    'location','southeast','Fontsize',21.5);
zlabel('$y$','Interpreter','latex');
xlabel('$Re(\mathbf{u})$','Interpreter','latex');
ylabel('$Im(\mathbf{u})$','Interpreter','latex');
set(gca,'Fontsize',20);
grid on

figure()
plot3(real(fx),imag(fx),ypts,'r-','linewidth',1.5); hold on
plot3(real(fy),imag(fy),ypts,'b-.','linewidth',1.5);
plot3(real(fz),imag(fz),ypts,'k--','linewidth',1.5);
legend('$Re(\hat{f}_x)$','$Re(\hat{f}_y)$','$Re(\hat{f}_z)$','interpreter','latex',...
    'location','southeast','Fontsize',21.5);
zlabel('$y$','Interpreter','latex');
xlabel('$Re(\mathbf{f})$','Interpreter','latex');
ylabel('$Im(\mathbf{f})$','Interpreter','latex');
set(gca,'Fontsize',20);
grid on

figure()
plot3(real(wx),imag(wx),ypts,'r-','linewidth',1.5); hold on
plot3(real(wy),imag(wy),ypts,'b-.','linewidth',1.5);
plot3(real(wz),imag(wz),ypts,'k--','linewidth',1.5);
legend('$Re(\hat{\eta}_x)$','$Re(\hat{\eta}_y)$','$Re(\hat{\eta}_z)$','interpreter','latex',...
    'location','southeast','Fontsize',21.5);
zlabel('$y$','Interpreter','latex');
xlabel('$Re(\mathbf{\eta})$','Interpreter','latex');
ylabel('$Im(\mathbf{\eta})$','Interpreter','latex');
set(gca,'Fontsize',20);
grid on
%% Isosurface
% x = linspace(0,2*pi(),N);
% [xx2,yy2,zz2] = meshgrid(z,ypts,x);
% iso_q=0.0005; %Pick your number here
% figure()
% p=patch(isosurface(xx2,yy2,zz2,wyr,iso_q,real(ur)));
% set(p,'FaceColor','interp','EdgeColor','none','Facealpha',0.8);
% grid on
% daspect([1,1,1])
% set(gca,'Fontsize',15)
% xlabel('$x$','Interpreter','latex')
% xlabel('$y$','Interpreter','latex')
% xlabel('$z$','Interpreter','latex')
% axis tight
% ax = -1; ay = 1; az = 1;
% view([ax,ay,az]);
% a = colorbar;
% a.Label.String = 'u - velocity';
% caxis([-0.05 0.05])
% camroll(240)
end