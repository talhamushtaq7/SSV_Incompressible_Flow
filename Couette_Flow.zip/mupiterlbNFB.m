function [lb,y,b] = mupiterlbNFB(M,opt)

r = size(M,1);
c = size(M,2);
MT = M';

% Parameters for Initialization
CNTMAX = opt.Iter;
stol = opt.stoptol;
b = opt.b0;
w = opt.w0;
newz = zeros(r,1);
newb = zeros(c,1);
nfull = opt.nbrblks;
converged = false;
cnt = 0;
lb = 0;

Dfull_maskrT = blkdiag(ones(r/nfull,1),ones(r/nfull,1),ones(r/nfull,1));
Dfull_maskcT = blkdiag(ones(c/nfull,1),ones(c/nfull,1),ones(c/nfull,1));
Dfull_maskr = Dfull_maskrT';
Dfull_maskc = Dfull_maskcT';
fullr = 1:size(M,1);
fullc = 1:size(M,2);

while ~converged && cnt<CNTMAX
    cnt = cnt + 1;

    % Power-Iteration
    newa = M*b;
    beta1 = norm(newa);
    newa = newa/beta1;

    wfull = w(fullc);
    afull = newa(fullr);

    norma = sqrt(Dfull_maskr*( conj(afull).*afull ));
    normw = sqrt(Dfull_maskc*( conj(wfull).*wfull ));

    tmp=zeros(nfull,1);
    idx = find(norma>100*eps*normw);
    tmp(idx) = normw(idx)./norma(idx);
    newz(fullr) = (Dfull_maskrT*tmp).*afull;

    neww = MT*newz;
    beta2 = norm(neww);
    neww = neww/beta2;

    if beta2 < 100*eps
        break;
    end

    wfull = w(fullc);
    afull = newa(fullr);

    norma = sqrt(Dfull_maskr*( conj(afull).*afull ));
    normw = sqrt(Dfull_maskc*( conj(wfull).*wfull ));

    tmp=zeros(nfull,1);
    idx = find(normw>100*eps*norma);
    tmp(idx) = norma(idx)./normw(idx);

    newb(fullc) = (Dfull_maskcT*tmp).*wfull;

    newlb = max(beta1,beta2);

    if abs( newlb-lb ) < stol || (isinf(newlb) && isinf(lb))
        chng = [newb; newa; newz; neww]-[b; a; z; w];
        if max(abs(chng)) < stol
            converged = true;
        end
    end

    lb = newlb;
    a = newa;
    b = newb;
    z = newz;
    w = neww;
end
y = M*b;
y = y/norm(y);
end
