function [ub,S] = method_of_centers(freq,lb,Re,N,kx,kz)
ratio = 1.05;
for ii = 1:length(kx)
    for jj = 1:length(kz)
        [linop] = get_linear_operator(Re,kx(ii),kz(jj),N,0);

        A = linop.A;
        B = linop.B;
        C_grad = linop.C_grad;

        nrc_grad = size(C_grad,1);
        ncb = size(B,2);

        H_grad = ss(A, B, C_grad, zeros(nrc_grad,ncb));
        M = evalfr(H_grad,freq*1i);

        blkstruct = [ncb/3, nrc_grad/3;...
            ncb/3, nrc_grad/3;...
            ncb/3, nrc_grad/3];
        
        % Initialize with Osborne method
        if jj <= 1 && ii <= 1
            [~,Dosb,~,~,~,~,~] = osborne_scaling(M,blkstruct);
            [ub(ii,jj),S{ii,jj}] = mumocubRFB(M,Dosb'*Dosb,lb(ii,jj),ratio);
        else
            if jj <= 1 && ii > 1
                [ub(ii,jj),S{ii,jj}] = mumocubRFB(M,S{ii-1,jj},lb(ii,jj),ratio);
            else
                [ub(ii,jj),S{ii,jj}] = mumocubRFB(M,S{ii,jj-1},lb(ii,jj),ratio);
            end
        end
    end
end
end