function [lb,y,f] = piterNFB(freq,Re,N,kx,kz,flag)

for ii = 1:length(kx)
    for jj = 1:length(kz)
        [linop] = get_linear_operator(Re,kx(ii),kz(jj),N,flag);

        A = linop.A; % System matrix
        B = linop.B; % Input mapping for forcings
        C_grad = linop.C_grad; % Output mapping for gradient of velocities
        IN = linop.IN; % Square root of L2 weight for (dxu,dyu,dzu,dxv,dyv,dzv,dxw,dyw,dzw)
        Iw = linop.Iw; % Square root of L2 weight for (u,v,w) or (fx,fy,fz)
        R = linop.R; % Square root of Kinetic Energy Weight

        nrc_grad = size(C_grad,1);
        ncb = size(B,2);

        H_grad = ss(R*A/R, R*B, C_grad/R, zeros(nrc_grad,ncb));
        M = evalfr(H_grad, freq*1i);
        M = IN * M / Iw;

        [~,~,vo] = svd(M);
        vo1 = vo(:,1);
        vo2 = vo(:,2);
        option.Iter = 60;
        option.stoptol = 1e-7;
        option.b0 = vo1;
        option.w0 = vo2;
        option.nbrblks = 3;

        [lb(ii,jj),y,f] = mupiterlbNFB(M,option);
        y = IN\y;
        f = Iw\f;

    end
end
end