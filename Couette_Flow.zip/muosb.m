function [Dleft, Dright, ub] = muosb(freq,Re,kx,kz,N,flag)

for ii = 1:length(kx)
    for jj = 1:length(kz)
        [linop] = get_linear_operator(Re,kx(ii),kz(jj),N,flag);

        A = linop.A;
        B = linop.B;
        C_grad = linop.C_grad;
        IN = linop.IN;
        Iw = linop.Iw;
        R = linop.R;

        nrc_grad = size(C_grad,1);
        ncb = size(B,2);

        H_grad = ss(R*A/R, R*B, C_grad/R, zeros(nrc_grad,ncb));
        M = evalfr(H_grad, freq*1i);
        M = IN * M / Iw;

        blkstruct = [ncb/3, nrc_grad/3;...
            ncb/3, nrc_grad/3;...
            ncb/3, nrc_grad/3];

        % Initialize with Osborne method
        [~,~,Dleft,Dright,~,~,~,ub(ii,jj)] = osborne_scaling(M,blkstruct);
    end
end