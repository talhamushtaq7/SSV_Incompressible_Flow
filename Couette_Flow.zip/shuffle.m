function [V,L,T] = shuffle(N)
I = eye(N);
Z = zeros(N,N);
I1 = [I,Z,Z]; I2 = [Z,I,Z]; I3 = [Z,Z,I];
V1 = blkdiag(I1,I1,I1);
V2 = blkdiag(I2,I2,I2);
V3 = blkdiag(I3,I3,I3);
V = [V1;V2;V3];
L = [blkdiag(I,I,I);blkdiag(I,I,I);blkdiag(I,I,I)];
J = [];
for i = 1:N
    E = [zeros(1,i-1),1, zeros(1,N-i)];
    J =[J; blkdiag(E,E,E)];

end
T = blkdiag(J,J,J);
end