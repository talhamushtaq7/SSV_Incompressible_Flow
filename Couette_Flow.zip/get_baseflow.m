function baseflow = get_baseflow(cdiff,Re,flag)
ypts = cdiff.y;

N = length(ypts);  % Number of grid points
if nargin<2
    % Default Channel Flow
    flag = 0;
end

if flag == 0

    baseflow.u  = 1 - ypts.^2;
    baseflow.uprime = -2*ypts;
    baseflow.udblprime= -2*ones(size(ypts));

elseif flag == 1

    baseflow.u  = ypts;
    baseflow.uprime = ones(size(ypts));
    baseflow.udblprime= zeros(size(ypts));

elseif flag == 2
c2 = 0.426; % optimal parameter in R-T eddy-viscosity
c1 = 25.4;  % optimal parameter in R-T eddy-viscosity
dy = cdiff.D1;
dyy = cdiff.D2;
I = eye(N);
%Reynolds-Tiederman eddy viscosity %
nuT = 0.5.*( (1 + ( (c2/3)*Re*(1 - ypts.^2).*(1 + 2*ypts.^2).*(1 - exp(-(1 - abs(ypts))*Re/c1)) ).^2 ).^(1/2) - 1  );
lhs = (diag(nuT)*dyy + diag(dy * nuT)*dy ) + dyy;
rhs = -Re.*ones(N,1);
U0 = lhs\rhs;
baseflow.u = U0;
baseflow.uprime = dy*U0;
baseflow.udblprime = dyy*U0;
else
    error('Baseflow undefined. Check flag variable value')
end

