function [ub,lb,lbt,VDelta,VSigma,VLmi] = more_struct(freq,Re,N,kx,kz,flag)
[V,L,Z] = shuffle(N);

for ii = 1:length(kx)
    for jj = 1:length(kz)
        [linop] = get_linear_operator(Re,kx(ii),kz(jj),N,flag);
        
        A = linop.A;
        B = linop.B*L'*Z';
        C_grad = Z*V*linop.C_grad;
        W = linop.Iw;
        R = linop.IN;
        

        nrc_grad = size(C_grad,1);
        ncb = size(B,2);

        H_grad = ss(A, B, C_grad, zeros(nrc_grad,ncb));
        M = evalfr(H_grad, freq*1i);

        blkstruct = repmat([3,0],3*N,1);

        [bounds,muinfo] = mussv(M,blkstruct,'Uf');
        [VDelta,VSigma,VLmi] = mussvextract(muinfo);
        ub(ii,jj) = bounds(1); lb(ii,jj) = bounds(2);
        lbt(ii,jj) = 1/norm(L'*Z'*VDelta*Z*V);

    end
end

end