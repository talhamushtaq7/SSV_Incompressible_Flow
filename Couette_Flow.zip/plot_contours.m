function [] = plot_contours(kz,kx,Z)
[val,ind] = max(Z);
[val2,ind2] = max(val);

figure()
pcolor(kz,kx,Z); hold on
% plot3(kz(ind2),kx(ind(ind2)),val2,'ko','linewidth',1.5);
shading interp
% title('$log_{10}\|H_{\nabla}\|_\mu$','interpreter','latex');
xlabel('$\kappa_z$','interpreter','latex');
ylabel('$\kappa_x$','interpreter','latex');
set(gca,'Xscale','log','Yscale','log','Fontsize',15)
colormap jet
colorbar
xlim([min(kz) max(kz)])
ylim([min(kx) max(kx)])
% clim([1 3])
end