function [lb,Delta,y,u] = mupiterlbRFB(M,blk,opt)
% [lb,Delta,y,u,muinfo] = mupiterlbRFB(M,blk,opt)
% Computes the power iteration lower bound for Fu(M,Delta) where the
% uncertainty is a repeated full block:
%   Delta = blkdiag(Delta1,Delta1,Delta1).
% It is assumed that Delta1 is nc-by-nr and M is (3*nr)-by-(3*nc). It is
% assumed that M and Delta can be complex, in general. The input blk gives
% the dimensions of Delta1 as blk = [nc, nr].
%
% **NOTE**-The "nc" refers to the row dimension of Delta1 and "3*nc"
% corresponds to the column dimension of M. Thus the "r"/"c" corresponds
% to row/columns of M in order to align with more general MUSSV notation.
%
% The lower bound is computed using a power iteration that generalizes
% the standard power iterations for computing the spectral radius and
% maximum singular value.
%
% Example:
%  rng(0);  % Set seed
%  nr = 3; nc = 7;
%  M = crandn(3*nr,3*nc);
%  blk = [nc nr];
%
%  % Compute bound using repeated blocks
%  [lb,Delta,y,u,muinfo] = mupiterlbRFB(M,blk);
%
%  % Verify results: y=M*u, u=Delta*y, norm(Delta)=1/lb
%  [norm(M*u-y) norm(u-Delta*y), 1/lb-norm(Delta)]
%
%  % Verify block structure: Delta = blkdiag(Q,Q,Q)
%  Q = Delta(1:nc,1:nr);
%  y1 = y(1:nr); y2=y(nr+1:2*nr); y3=y(2*nr+1:end);
%  u1 = u(1:nc); u2=u(nc+1:2*nc); u3=u(2*nc+1:end);
%  [norm(u1-Q*y1), norm(u2-Q*y2) norm(u3-Q*y3)]
%
%  % Check against LMI upper bound: Should have ub>=lb
%  [ub,muubinfo] = mulmiubRFB(M,blk);
%  [lb ub]


% Process inputs
if nargin==3
    Niter = opt.Iter;
    stoptol = opt.stoptol;
    bstart = opt.b0;
    wstart = opt.w0;
else
    Niter = [];
    stoptol = [];
    bstart = [];
    wstart = [];
end

% Matrix and uncertainty block dimensions
[Mr,Mc]=size(M);
nblk = size(blk,1);
nr = Mr/nblk;
nc = Mc/nblk;
Q1 = zeros(nr,nc);
Q2 = zeros(nr,nc);

if ~( (Mr==nblk*nr) &&  (Mc==nblk*nc) )
    error('Dimensions of M should be 3*blk(2) by 3*blk(1)');
end

% Default values
if isempty(Niter)
    Niter = 100;
end
if isempty(stoptol)
    stoptol = 1e-4;
end
if isempty(bstart)
    % Starting values from mmupiter
    [~,~,v] = svd(M);
    b = v(:,1) + 0.01;
    bstart = b/norm(b);
    w = v(:,2) + 0.01;
    wstart = w/norm(w);
end
newz = zeros(Mr,1);
newb = zeros(Mc,1);
a = zeros(Mr,1);
z = zeros(Mr,1);
b = bstart;
w = wstart;

% Perform iteration
MT = M';
converged = false;
cnt = 0;
lb = 0;


while ~converged && cnt<=Niter
    cnt = cnt + 1;
    
    % Multiply by M
    newa = M*b;
    beta1 = norm(newa);
    newa = newa/beta1;
    
    % Alignment: Compute newz
    Lw1 = reshape(w,[nc nblk]);
    La1 = reshape(newa,[nr nblk]);
    [U1,~,V1] = svd(La1*Lw1');
    dim = min(nr,nc);
    Q1 = U1(:,1:dim)*V1(:,1:dim)';
    Lz1 = Q1*Lw1;
    newz = Lz1(:);
    
    % Multiply by M'
    neww = MT*newz;
    beta2 = norm(neww);
    neww = neww/beta2;
    
    % Alignment: Compute newb
    Lw2 = reshape(neww,[nc nblk]);
    La2 = reshape(newa,[nr nblk]);
    [U2,~,V2] = svd(Lw2*La2');
    dim = min(nr,nc);
    Q2 = U2(:,1:dim)*V2(:,1:dim)';
    Lb2 = Q2*La2;
    newb = Lb2(:);
    % Stopping Conditions
    newlb = max(beta1,beta2);
    if abs( newlb-lb ) < stoptol
        chng = [newb; newa; newz; neww]-[b; a; z; w];
        if max(abs(chng)) < stoptol
            converged = true;
        end
        %         max(abs(chng))
    end
    
    % Update (If not the final iteration)
    lb = newlb;
    a = newa;
    b = newb;
    z = newz;
    w = neww;
end

% Finalize outputs
if ~converged
    % Failed to converge. Take best lower bound from the two perturbations.
    Delta1 = kron(eye(nblk),Q1'); % Norm 1
    [V1,E1] = eig(Delta1*M);   
    E1 = diag(E1);
    [lb1,idx1] = max(abs(E1));
    
    Delta2 = kron(eye(nblk),Q2); % Norm 1
    [V2,E2] = eig(Delta2*M);   
    E2 = diag(E2);
    [lb2,idx2] = max(abs(E2));
    
    if lb1>=lb2
        lb = lb1;
        Delta = Delta1/E1(idx1);
        u = V1(:,idx1);
        y = M*u;
    else
        lb = lb2;
        Delta = Delta2/E2(idx2);
        u = V2(:,idx2);
        y = M*u;
    end        
elseif beta1>=0.999*beta2
    % beta1*a=M*b, b=blkdiag(Q2,Q2,Q2)*a <--> y = M*u, b=Delta*u
    lb = beta1;
    Delta = kron(eye(nblk),Q2)/lb;
    u = b;
    y = beta1*a;
    y = y./norm(y);
else
    % beta2*w=M'*z, z=blkdiag(Q1,Q1,Q1)*w
    % Need to transpose in this case to get signals y=M*u, b=Delta*u
    Delta2 = kron(eye(nblk),Q1)';
    [~,EE] = eig(Delta2*M);
    [lb1,~] = max(abs(EE));
    [~,idx] = max(lb1);
    
    Delta = Delta2 ./ EE(idx,idx);
    lb = 1/norm(Delta,2);
    [V2,E2] = eig(Delta*M);
    Emag2 = abs(diag(E2));
    [~,idx2] = min( abs(Emag2-1) );
    u = V2(:,idx2);
    y = M*u;
end


