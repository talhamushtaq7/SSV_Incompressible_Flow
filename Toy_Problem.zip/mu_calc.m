function [ub,lb] = mu_calc(freq,A, B, C, flag_func)

        nrc = size(C,1);
        ncb = size(B,2);

        H = ss(A, B, C, zeros(nrc,ncb));
        M = evalfr(H, freq*1i);
        % M = IN * M / Iw;

        blkstruct = [ncb/2, nrc/2;...
                     ncb/2, nrc/2];


        if flag_func == 0
            % % Lower Bounds (Non-Repeated)
            [~,~,~,~,dMd,~,~,ub] = osborne_scaling(M,blkstruct);
            %
            [~,~,vo] = svds(dMd,1); %svd(M);
            vo1 = vo(:,1);
            % vo2 = vo(:,2);
            option.Iter = 60;
            option.stoptol = 1e-7;
            option.b0 = vo1;
            option.w0 = vo1; %vo2;
            option.nbrblks = 2;

            [lb,~,~] = mupiterlbNFB(dMd,option);

%             % % Upper Bounds (Non-Repeated)
%             ratio = 1.05;
% %             blkstruct = [ncb/2, nrc/2;...
% %                          ncb/2, nrc/2];
%             % Initialize with Osborne method
%             [~,Dosb,~,~,~,~,~] = osborne_scaling(M,blkstruct);
%             [ub,~] = mumocubNFB(M,Dosb'*Dosb,lb,ratio);


        elseif flag_func == 1
            % % Lower Bounds (Repeated)
            [~,Dosb,~,~,dMd,~,~,~] = osborne_scaling(M,blkstruct);
            %
            [~,~,vo] = svds(dMd,1); %svd(M);
            vo1 = vo(:,1);
            % vo2 = vo(:,2);
            option.Iter = 80;
            option.stoptol = 1e-7;
            option.b0 = vo1;
            option.w0 = vo1; %vo2;

            [lb,~,~,~] = mupiterlbRFB(dMd,blkstruct,option);

            % % Upper Bounds (Repeated)
            ratio = 1.05;
        % Initialize with Osborne method
        % [~,Dosb,~,~,~,~,~] = osborne_scaling(M,blkstruct);
        gam = min(diag(Dosb));
        Dosb = (1/gam)*Dosb;
        [ub,~] = mumocubRFB(M,Dosb'*Dosb,lb,ratio);

        end
    %end
% end

end