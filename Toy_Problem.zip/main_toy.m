clear
clc
close all
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
flag_func = 1; % flag_func = 0 (Non-Repeated), flag_func = 1 (Repeated)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Frequency
nf = 100; % Number of (positive) frequency points
w1 = logspace(-4,1.5,nf);
w = sort([-w1,w1]);
%% Bound Calculation
clc
% rng default;
% rng(2,"twister");
% A = crandn(4,4); B = crandn(4); C = crandn(4);
N=10; % Number of runs
for ct=1:N
    % Get random matrices
    rng("shuffle","twister");
    A = crandn(4,4); B = crandn(4); C = crandn(4);
    sys{ct} = {A,B,C}; % Save the matrices for later use
    %% Non-repeated case
        parfor ii = 1:length(w)
            % disp(ii)
            [ub_fr_NFB(ii),lb_fr_NFB(ii)] = mu_calc(w(ii),A,B,C, 0);
        end
        UB_NFB(ct) = max(ub_fr_NFB);
    %% Repeated case
        parfor ii = 1:length(w)
            %disp(ii)
            [ub_fr_RFB(ii),lb_fr_RFB(ii)] = mu_calc(w(ii),A,B,C, 1);
        end
        UB_RFB(ct) = max(ub_fr_RFB);
end
%% Maximum discrepancy b/w the upper bounds
[val,ind] = max(100*(UB_NFB./UB_RFB-1)); %max(UB_NFB-UB_RFB);
%
A = sys{1,ind}{1,1}; B = sys{1,ind}{1,2}; C = sys{1,ind}{1,3};
%
% The non-repeated case
flag_func = 0;
parfor ii = 1:length(w)
    % disp(ii)
    [ub_fr_NFB(ii),lb_fr_NFB(ii)] = mu_calc(w(ii),A,B,C,flag_func);
end
%
% The repeated case
flag_func = 1;
parfor ii = 1:length(w)
    % disp(ii)
    [ub_fr_RFB(ii),lb_fr_RFB(ii)] = mu_calc(w(ii),A,B,C,flag_func);
end
%---------------------------------------------------
% %% Check (optional) with mussv with the Uf option (Osborne iteration)
% nrc = size(C,1);
% ncb = size(B,2);
% 
% blkstruct = [ncb/2, nrc/2;...
%              ncb/2, nrc/2];
% 
% parfor ii = 1:length(w)
%     H = ss(A, B, C, zeros(nrc,ncb));
%     M = evalfr(H, w(ii)*1i);
%     [bounds,~] = mussv(M,blkstruct,'Uf');
%     ub_fr_mussv(ii) = bounds(1); lb_fr_mussv(ii) = bounds(2);
% end
% %%%%%%%%%
% figure()
% plot(w,100*(ub_fr_NFB-ub_fr_mussv)./ub_fr_NFB,'k-','linewidth',1.5);
% hold on;
% plot(w,100*(lb_fr_NFB-lb_fr_mussv)./lb_fr_NFB,'r--','linewidth',1.5);
% grid on;
% xlabel('$\omega$','interpreter','latex');
% % ylabel('$100(\alpha/\beta - 1)$','interpreter','latex');
% set(gca,'Fontsize',15);
% xlim([-10, 10]); % xlim([min(w), max(w)]);
% legend('\alpha','\beta');
% title('Diff in NFB and mussv results (%)');
%%
% figure()
% plot(w,ub_fr_NFB,'r-','linewidth',1.5);
% hold on;
% plot(w,lb_fr_NFB,'r--','linewidth',1.5);
% % plot(w,ub_fr_RFB,'r--','linewidth',1.5);
% grid on;
% xlabel('$\omega$','interpreter','latex');
% ylabel('$\alpha$','interpreter','latex');
% set(gca,'Fontsize',15);
% xlim([-10, 10]); % xlim([min(w), max(w)]);
% legend('NFB','RFB');
% title('Upper Bounds');

if min(ub_fr_NFB-lb_fr_NFB) < 0
    disp('Inconsistent bounds for NFB, i.e., LB > UB')
else
    figure()
    plot(w,ub_fr_NFB,'r-','linewidth',1.5);
    hold on;
    plot(w,lb_fr_NFB,'k--','linewidth',1.5);
    % plot(w,ub_fr_RFB,'r--','linewidth',1.5);
    grid on;
    xlabel('$\omega$','interpreter','latex');
    ylabel('$\alpha,~\beta$','interpreter','latex');
    set(gca,'Fontsize',15);
    xlim([-10, 10]); % xlim([min(w), max(w)]);
    legend('\alpha','\beta');
    title('Non-Repeated Complex Full-Blocks');
end

%%
% figure()
% plot(w,lb_fr_NFB,'k-','linewidth',1.5);
% hold on;
% plot(w,lb_fr_RFB,'r--','linewidth',1.5);
% grid on;
% legend('\alpha');
% xlabel('$\omega$','interpreter','latex');
% ylabel('$\beta$','interpreter','latex');
% set(gca,'Fontsize',15);
% xlim([-6, 6]); % xlim([min(w), max(w)]);
% legend('NFB','RFB');
% title('Lower Bounds');

if min(ub_fr_RFB-lb_fr_RFB) < 0
    disp('Inconsistent bounds for RFB, i.e., LB > UB')
else
    figure()
    plot(w,ub_fr_RFB,'r-','linewidth',1.5);
    hold on;
    plot(w,lb_fr_RFB,'k--','linewidth',1.5);
    % plot(w,ub_fr_RFB,'r--','linewidth',1.5);
    grid on;
    xlabel('$\omega$','interpreter','latex');
    ylabel('$\alpha,~\beta$','interpreter','latex');
    set(gca,'Fontsize',15);
    xlim([-10, 10]); % xlim([min(w), max(w)]);
    ylim([0 70]);
    legend('\alpha','\beta');
    title('Repeated Complex Full-Blocks');
end

%%
figure()
plot(w,100*(ub_fr_NFB-lb_fr_NFB)./lb_fr_NFB,'k-','linewidth',1.5);
hold on;
plot(w,100*(ub_fr_RFB-lb_fr_RFB)./lb_fr_RFB,'r--','linewidth',1.5);
grid on;
xlabel('$\omega$','interpreter','latex');
ylabel('$100(\alpha/\beta - 1)$','interpreter','latex');
set(gca,'Fontsize',15);
xlim([-10, 10]); % xlim([min(w), max(w)]);
legend('NFB','RFB');
title('Gap in the bounds (%)');
