function [ub,S] = mumocubNFB(M,S0,lb,rat)
% function [ub,Dr,Dc,S] = mumocub(M,S0)
%
% Notation:
%   1)  ub^2*Xc - M'*Xr*M  > 0
%   2)            S > dmin*I
%   3)            dmax*I > S
% where Xr = kron(S'*S,eye(nr)), Xc = kron(S'*S,eye(nc)) and S is v-by-v.
% Comments:
%  A) Constraints 2) and 3) should be implemented on S as this is
%     probably faster.
%  B) Tolerance on inner loop is probably too tight as it seems to always
%     max out the number of inner-loop steps.
%  C) Implement heavy ball on inner-loop steps?
%  D) Is mat2cell + cellfun too slow?
% Modified: Talha Mushtaq July 31, 2022

%% Display Flag for Debugging
dispflag = false;

%% Dimensions
% Dimensions should be S0 is v-by-v and M is Mr-by-Mc with Mr=v*nr
% and Mc = v*nc.  We could add error checking for this.
[Mr,Mc] = size(M);
v = size(S0,1);
nr = round(Mr/v);
nc = round(Mc/v);
nrblk = repmat(nr,[1 v]);
ncblk = repmat(nc,[1 v]);

%%  Options
% if nargin > 3
%     Nostep = Nu;  % 20
% elseif nargin <= 2
%     lb = 0;
% else
%     Nostep = 200;  % 20
% end
dmin = 1;
dmax = 1e4;
theta = 1e-3;
epsMC = 1e-4;  % 1e-4
Nistep = 2;  % 20


%Nistep = 5; theta = 1e-5;; epsMC = 1e-5;
%dmin = 1e-6; dmax = 1e6;

%% Initialization

% Check that initial S0 is feasible
e = real(eig(S0));
emax = max(e);
emin = min(e);
if (emax > dmax || emin <dmin)
    if (emax/emin < 0.9*dmax/dmin)
        S0 = S0*(0.9*dmax/emax);
    else
        S0 = eye(v);
    end
end

% Compute initial upper bound
S = S0;
Dr = kron(S,eye(nr));
Dc = kron(S,eye(nc));
MDM = M'*Dr*M;
MDM = (MDM+MDM')/2;
evals = eig(MDM,Dc);
ub = 1.01*sqrt( max(evals) );

%% Begin Display
ostep = 0;
if dispflag
    fprintf('\n');
    fprintf('Beginning Optimization Problem\n');
    fprintf('*----------------------------------------------------------*\n');
    fprintf('Step = %d \t Cost = %0.3f \n',ostep,ub);
end

%% Method of Centers
lambda = ub + 2*epsMC;
ubprev = inf;
Iv = eye(v);
while (ub/lb >= rat) && ub<=ubprev && isreal(ub) == 1 && ostep <= 500

    % Store prevoius values
    ubprev = ub;
%     Sprev = S;
    Drprev = Dr;
%     Dcprev = Dc;

    % Update cost
    lambda = (1-theta)*ub+theta*lambda;
    % Find analytic center of LMI constraints
    %  L1 := ub^2*Dc - M'*Dr*M >= 0
    %  L2 := S - dmin*I >= 0
    %  L3 := dmax*I - S >= 0

    go = true;
    istep = 0;
    while go
        % Compute LMI constraints
        L1 = lambda^2*Dc-M'*Dr*M;
        L1 = (L1+L1')/2;
        L2 = S - dmin*Iv;
        L3 = dmax*Iv - S;

        % Intermediate calculations involving L1
        if rcond(L1) >= 10*eps
            % Standard inverse
            invL1 = inv( L1 );
        else
            % Switch from inv to ldl to avoid ill-conditioning warnings.
            [LL,DD]=ldl(L1);
            LLt = LL';
            DDinv = diag(DD);
            DDinv( DDinv~=0 ) = 1./DDinv( DDinv~=0 );
            invL1 = LLt\lrscale(LL\eye(v*nc), DDinv ,[] );
        end
        %invL1 = inv( L1 );
        MinvL1 = M*invL1;
        MinvL1M = MinvL1*M';
        invL2 = inv( L2 );
        invL3 = inv( L3 );

        % Compute gradient of barrier function and form step direction
        %   J = real( -log(det(L1)) - log(det(L2)) - log(det(L3)) );
        Sstep1 = mat2cell(MinvL1M,nrblk,nrblk);
        Sstep1 = cellfun(@trace,Sstep1);
        Sstep1 = diag(diag(Sstep1));

        Sstep2 = mat2cell(invL1,ncblk,ncblk);
        Sstep2 = cellfun(@trace,Sstep2);
        Sstep2 = diag(diag(Sstep2));
        
        Sstep = Sstep1 - lambda^2*Sstep2 - invL2 + invL3;

        Drstep = kron(Sstep,eye(nr));
        Dcstep = kron(Sstep,eye(nc));

        % Exact line search
        L1step = lambda^2*Dcstep-M'*Drstep*M;
        %L1step = (L1step+L1step')/2;
        blkeigA = eig(L1step,L1);
        blkeigB = eig(Sstep,L2);
        blkeigC = eig(-Sstep,L3);

        blkeig = real([blkeigA; blkeigB; blkeigC]);
        tstep = LOCALlinesearch(-blkeig);
        if isnan(tstep) || isinf(tstep)
            go = false;
            break;
        end

        % Take gradient step
        istep = istep+1;

        S = S - tstep*Sstep;
        S = (S+S')/2;
        Dr = kron(S,eye(nr));
        Dc = kron(S,eye(nc));

        % Inner-loop stopping conditions
        if istep>=Nistep || (istep>=20 && tstep*norm(Drstep)/norm(Dr)<1e-5)
            go = false;
        end
    end

    % Update cost
    MDM = M'*Dr*M;
    MDM = (MDM+MDM')/2;
    evals = eig(MDM,Dc);
    ub = sqrt( max(evals) );

    % Count outer loop steps, compute tolerance, and print to screen
    ostep = ostep + 1;
    if dispflag
        fprintf('Step = %d \t Cost = %0.3f \t (Inner) Steps = %0.3f \n', ...
            ostep,ub,istep);
    end
end

if ubprev<ub || isreal(ub) == 0
    ub = ubprev;
    Dr = Drprev;
end
S = Dr(1:nr:end,1:nr:end);

%-----------------------------------------------------------------%
function alpha = LOCALlinesearch(blkeig)
% Exact line search

% Set recentering stop tolerance
epsNS = 1e-5;
delx = 2*epsNS;
t=0;

% Use Newton Method for Exact Line search
while (delx > epsNS) %&& (t<=1e20)
    % Compute gradient and Hessian for linesearch
    g = -sum(blkeig./(1+t*blkeig));
    H = sum(blkeig.^2./(1+t*blkeig).^2);
    v = g/H;

    % Compute error bound
    delx = sqrt(g'*v);

    % Nesterov and Nemirovskii damping rule
    if delx <= 1/4
        alpha = 1;
    else
        alpha = 1/(1+delx);
    end

    % Update t
    t = t-alpha*v;
end

% Optimal Step Size
alpha = min(t,1);
%alpha =t;

% function M_ij = sub_trace(M,ridx,cidx,nbrblks)
% M_ij = zeros(nbrblks,nbrblks) + 1i*zeros(nbrblks,nbrblks);
% for i = 1:nbrblks
%     for j = 1:nbrblks
%         M_ij(i,j) = trace(M((i-1)*ridx + 1:i*ridx,(j-1)*cidx + 1:j*cidx));
%     end
% end
