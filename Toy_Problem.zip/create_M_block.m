function [M_ij,N] = create_M_block(M,nbrblks,out,in)
ridx = out;
cidx = in;
for i = 1:nbrblks

    for j = 1:nbrblks

        % Calculate the 2-norm of each M_ij block, which corresponds to
        % |a_jp|^2 or |a_pj|^2 given in [1] (See Eqn. 10)

        M_ij{i,j} = M((i-1)*ridx + 1:i*ridx,(j-1)*cidx + 1:j*cidx);
        N(i,j) = norm(M_ij{i,j},'fro');
    end
end