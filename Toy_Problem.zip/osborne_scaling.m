function [dscale,D,Dleft,Dright,dMd,M2,t1,ub] = osborne_scaling(M,simpleblk)
% Reference: [1] On the Preconditioning of Matrices, E.E.Osborne

% Number of Equally Dimensioned Uncertain Blocks
nbrblks = size(simpleblk,1);
% sz1 = index.sz1;
% sz2 = index.sz2;

for ii = 1:nbrblks
    % System Input and Output dimension for each block matrix in Delta
    in(ii) = simpleblk(ii,1);
    out(ii) = simpleblk(ii,2);
end

N = zeros(nbrblks,nbrblks);

[~,N] = create_M_block(M,nbrblks,out,in);

ridx = out(1);
cidx = in(1);
%%  Scaling iterations

% if opt == 1 % Osborne Iteration (Unequal Block Diagonal Uncertainty)

% Zero out the diagonals because they are not included in calculating R and
% S in [1] (See Eqn. 10)
% [Q,N] = schur(N);
% No = N;
tst = tic;
newcost = 0;
N = N - diag(diag(N));
d = ones(1,nbrblks);
tol = 1e-5;
oldcost = sum(sum(N));
Nint = N;

%-------------------------------------------------------------
% Osborne Iteration
while abs(oldcost - newcost) >= tol
    oldcost = newcost;
    for jj = 1:nbrblks % For each Uncertain block
        % Calculate R and S as given in [1] (See Eqn. 10)
        S = sqrt(sum(N(:,jj)));
        R = sqrt(sum(N(jj,:)));
        % Calculate the scaling as given in [1] (See Eqn. 12)
        d(jj) = d(jj).*sqrt(S/R);
    end
    % For each M_ij block we have d_i/d_j when you carry out the
    % multiplication D*M*D^-1. Hence m_scale calculates d_i/d_j
    m_scale = d'*(1./d);
    N = Nint.*(m_scale);
    newcost = sum(sum(N)); % New cost of the system
end
% Final scaling matrix normalized by the first value of d
dscale = d;

vec_left = repmat(dscale,[ridx,1]);
vec_left = reshape(vec_left,[],1);

vec_right = repmat(1./dscale,[cidx,1]);
vec_right = reshape(vec_right,[],1);

Dleft = diag(vec_left);
Dright = inv(diag(vec_right));
D = diag(d);
dMd = lrscale(M,vec_left,vec_right);
ub = norm(dMd);
t1 = toc(tst);
M2 = dMd;
end
